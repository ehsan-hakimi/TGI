(function () {

    // jQuery library is required in this sample
  
(window.jQuery || document.write('<script src="//ajax.aspnetcdn.com/ajax/jquery/jquery-1.10.0.min.js"><\/script>')); 

    
    // Create object that have the context information about the field that we want to change it's output render 
    var accordionContext = {};
    accordionContext.Templates = {};

    // Be careful when add the header for the template, because it's will break the default list view render
    //accordionContext.Templates.Header = "<div class='accordion' id='accordion'>";
    //accordionContext.Templates.Footer = "</div>";

    // Add OnPostRender event handler to add accordion click events and style
    accordionContext.OnPostRender = accordionOnPostRender;

    // This line of code tell TemplateManager that we want to change all HTML for view render
    accordionContext.Templates.View = RenderAccordionViewBodyTemplate;

    SPClientTemplates.TemplateManager.RegisterTemplateOverrides(accordionContext);

})();

// This function provides the rendering logic
function RenderAccordionViewBodyTemplate(ctx) {

        var listData = ctx.ListData; 
          if (ctx.Templates.Body == '') { 
              return RenderViewTemplate(ctx); 
          } 
          var accordionHtml =''; 
          var categoryID =''; 
		  
          accordionHtml = '<div class="accordian" id="accordionFAQ">'; 
          for (var idx in listData.Row) {
			     
                 var listItem = listData.Row[idx]; 
				 if(categoryID != listItem.Category[0].lookupId){
					if(categoryID !=''){accordionHtml +='</div>';}
					accordionHtml = accordionHtml+'<h3>'+listItem.Category[0].lookupValue+'</h3>'+'<div class="accordian">';					
				 }
                 categoryID = listItem.Category[0].lookupId;
				 if(listItem.Body != ''){
					 accordionHtml += '<h3>'; 
					 accordionHtml += listItem.SubCategory[0].lookupValue;
					 accordionHtml += '</h3>'; 
					 accordionHtml += '<div>'; 
					 accordionHtml += listItem.Body; 
					 accordionHtml += '</div>';
				}				 
          } 
          accordionHtml +='</div>';
          accordionHtml += '</div>'; 
           
          return accordionHtml; 
}

function accordionOnPostRender() {
    
    // Register event to collapse and uncollapse when click on accordion header
	$("div.accordian").accordion({
        heightStyle: "content",
		collapsible: true,
		active: false,
    });
}